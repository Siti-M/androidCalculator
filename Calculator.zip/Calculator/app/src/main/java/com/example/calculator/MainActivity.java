package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Button btnHasiltabung, btnHasilkerucut, btnHasilbola;
    private TextView tvHasil;
    private EditText etJari, etTinggi;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnHasiltabung = findViewById(R.id.btn_hasiltabung);
        btnHasilkerucut = findViewById(R.id.btn_hasilkerucut);
        btnHasilbola = findViewById(R.id.btn_hasilbola);
        tvHasil = findViewById(R.id.tv_hasil);
        etJari = findViewById(R.id.et_jari);
        etTinggi = findViewById(R.id.et_tinggi);

        btnHasiltabung.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String sJari = etJari.getText().toString();
                String sTinggi = etTinggi.getText().toString();

                Double Jari = Double.parseDouble(sJari);
                Double Tinggi = Double.parseDouble(sTinggi);

                Double tabung = Math.PI*Jari*Jari*Tinggi;
                String sHasilTabung = String.valueOf(tabung);
                tvHasil.setText(sHasilTabung);
            }
        });

        btnHasilkerucut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String sJari = etJari.getText().toString();
                String sTinggi = etTinggi.getText().toString();

                Double Jari = Double.parseDouble(sJari);
                Double Tinggi = Double.parseDouble(sTinggi);

                Double kerucut = 1*(Math.PI*Jari*Jari*Tinggi)/3;
                String sHasilKerucut = String.valueOf(kerucut);
                tvHasil.setText(sHasilKerucut);
            }
        });

        btnHasilbola.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String sJari = etJari.getText().toString();
                String sTinggi = etTinggi.getText().toString();

                Double Jari = Double.parseDouble(sJari);
                Double Tinggi = Double.parseDouble(sTinggi);

                Double bola = 4*(Math.PI*Jari*Jari*Jari*Tinggi)/3;
                String sHasilBola = String.valueOf(bola);
                tvHasil.setText(sHasilBola);
            }
        });
    }
}
